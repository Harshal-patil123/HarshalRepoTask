create database mern;
use mern;

create table user (id integer primary key auto_increment, firstName varchar(15), lastName varchar(15), phone varchar(12), email varchar(50), password varchar(100));
ALTER TABLE user ADD UNIQUE (email);


ALTER TABLE user ADD COLUMN status int(1);

const jwt = require("jsonwebtoken");
const secret = "123412341234";

function client() {
  const data = { id: 1 };
  

  //created token 
  const token = jwt.sign(data, secret);
  console.log(token);
}
// client();

function server() {
  const token = `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNjgyODY1OTQ1fQ.cMjWJe0CMWWC6Rz7J52kxqAf8-AitPPPgJHbQQR1wqo`;

  // verifying above token coming from client at server 
  const data = jwt.verify(token, secret);
  console.log(data);
}
server();

module.exports = {
  secret: "abcdefghijsdfladnsdlfnadf234234sf2134324",
};
